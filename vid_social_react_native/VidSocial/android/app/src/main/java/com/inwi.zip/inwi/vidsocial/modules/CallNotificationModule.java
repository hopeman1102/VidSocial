package com.inwi.vidsocial.modules;




import static com.inwi.vidsocial.notification.RNPushNotificationListenerService.CALLER_NAME;
import static com.inwi.vidsocial.notification.RNPushNotificationListenerService.ROOM_NAME;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.inwi.vidsocial.notification.HeadsUpNotificationService;

import org.json.JSONException;
import org.json.JSONObject;

public class CallNotificationModule extends ReactContextBaseJavaModule {

    Vibrator vibrator;

    private static final String TAG = CallNotificationModule.class.getSimpleName();

    public CallNotificationModule(ReactApplicationContext context) {
        super(context);
    }

    @NonNull
    @Override
    public String getName() {
        return "CallNotificationModule";
    }

    @ReactMethod
    public void startVibration(){
        vibrator = (Vibrator) getReactApplicationContext().getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);

        // Start without a delay
        // Vibrate for 100 milliseconds
        // Sleep for 1000 milliseconds

        long[] pattern = {0, 400, 200, 400, 200, 300, 1000};

        // The '0' here means to repeat indefinitely
        // '0' is actually the index at which the pattern keeps repeating from (the start)
        // To repeat the pattern from any other point, you could increase the index, e.g. '1'
        vibrator.vibrate(pattern, 0);
    }

    @ReactMethod
    public void stopVibration(){
        try {
            if (vibrator != null && vibrator.hasVibrator())
                vibrator.cancel();
        }catch (Exception e){
            Log.e(TAG,"Vibration Stop Error:"+e.getMessage());
        }
    }

    @ReactMethod
    public void setCallerInfo(ReadableMap callInfo, ReadableMap callerInfo) {
            //CALL_INFO = callInfo;
           //CALLER_INFO = callerInfo;
            CALLER_NAME = callerInfo.getString("displayname");
    }

    @ReactMethod
    public void showNotification(ReadableMap message, String userName) {
        try {
            Log.d(TAG,"Call Notification ====> 1");
            ReadableMap data = message.getMap("data");
            JSONObject msg = new JSONObject(data.getString("alert"));
//            if (!appState.equals("active")) {
                if (msg.has("channelname")) {
                    Log.d(TAG,"Call Notification ====> 2: "+msg.toString());
                    ROOM_NAME = msg.getString("channelname");
                    CALLER_NAME = userName;
                    Intent serviceIntent = new Intent(getReactApplicationContext().getApplicationContext(), HeadsUpNotificationService.class);
                    Bundle mBundle = new Bundle();
                    mBundle.putString("type", "call");
                    mBundle.putString("title", CALLER_NAME);
                    mBundle.putString("body", data.getString("body"));
                    Log.d(TAG,"Call Notification Data 1: "+new JSONObject(data.toHashMap()).toString());
                    mBundle.putString("data", new JSONObject(data.toHashMap()).toString());
                    serviceIntent.putExtras(mBundle);
                    ContextCompat.startForegroundService(getReactApplicationContext(), serviceIntent);
                } else if (msg.has("callerroom")
                    && msg.getString("callerroom").equals(ROOM_NAME)
                    && msg.getInt("callresponse") == -2) {
                }
//            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @ReactMethod
    public void closeCallNotification(){
        Context context = getReactApplicationContext().getApplicationContext();
        Intent i = new Intent();
        i.setAction("com.lockscreenactivity.action.close");
        i.setPackage(context.getPackageName());
        i.putExtra("msg","hello");
        context.sendBroadcast(i);
        context.stopService(new Intent(context, HeadsUpNotificationService.class));
    }

    @ReactMethod
    public void clearNotification(ReadableMap message,String userName){
        try {
            ReadableMap data = message.getMap("data");
//            Log.d(TAG, "Call Message Received:===> " + message.toString() + " - " + appState);
            JSONObject msg = new JSONObject(data.getString("alert"));
            Intent serviceIntent = new Intent(getReactApplicationContext(), HeadsUpNotificationService.class);
            Bundle mBundle = new Bundle();
            mBundle.putString("type", "cancel_call");
            mBundle.putString("title", userName);
            serviceIntent.putExtras(mBundle);
            ContextCompat.startForegroundService(getReactApplicationContext(), serviceIntent);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
