package com.inwi.vidsocial.notification;


import static  com.inwi.vidsocial.notification.RNPushNotificationListenerService.appState;

import android.app.Application;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.bumptech.glide.Glide;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationHelper;
import com.facebook.react.ReactActivity;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
//import  com.inwi.vidsocial.R;
import com.inwi.vidsocial.notification.HeadsUpNotificationService;
import com.inwi.vidsocial.notification.LockScreenActivityInterface;
import  com.inwi.vidsocial.notification.utils.NotificationUtils;
import com.vidsocial.R;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class LockScreenActivity extends ReactActivity implements LockScreenActivityInterface {

    private static final String TAG = "LockScreenActivity";
    public static final String CALL_CANCELLED = "com.lockscreenactivity.action.close";
//    private Ringtone ringtone;
    private String title, body, notification;
    LocalBroadcastManager mLocalBroadcastManager;
    BroadcastReceiver mBroadcastReceiver;
    private boolean fallBack;
    private int notifID;
    private Window wind;

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_screen);
        wind = getWindow();
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            wind.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            keyguardManager.requestDismissKeyguard(this, null);

            wind.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            wind.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            wind.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
//        wind.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
            wind.addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            wind.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        Intent intent = getIntent();
        notifID=intent.getIntExtra("NOTIFICATION_ID", -1);
        title = intent.getStringExtra("title");
        body = intent.getStringExtra("body");
        notification = intent.getStringExtra("data");
        //ringtoneManager start
//        Uri incoming_call_notif = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
//        this.ringtone= RingtoneManager.getRingtone(getApplicationContext(), incoming_call_notif);
        //ringtoneManager end

        fallBack = intent.getBooleanExtra("FALL_BACK",true);
//            if(!fallBack) {
//                ringtone.setLooping(true);
//                ringtone.play();
//            }

        final Boolean isAppRuning=intent.getBooleanExtra("APP_STATE",false);

        TextView tvName = (TextView)findViewById(R.id.callerName);
        tvName.setText(title);

        Button iconName = findViewById(R.id.icon_text);
        if(title!=null && !title.trim().equals(""))
            iconName.setText(title.substring(0,1).toUpperCase(Locale.ROOT));

        TextView callType = findViewById(R.id.callType);

        ImageView profileImage = findViewById(R.id.profileImage);
        Glide.with(this).load(getDrawable(R.drawable.src_icons_person_icon)).circleCrop().into(profileImage);
        try {
            JSONObject data = new JSONObject(notification);
            JSONObject messsage = new JSONObject(data.getString("alert"));
            callType.setText(messsage.getString("call_type")+ " Call");

            if(messsage.getString("profileImageUrl").contains("http")){
                Glide.with(this).load(messsage.getString("profileImageUrl")).circleCrop().into(profileImage);
            }else if(messsage.getString("gender").equals("F")){
                Glide.with(this).load(getDrawable(R.drawable.src_icons_person_icon)).circleCrop().into(profileImage);
            }else{

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        final ReactContext reactContext = getReactInstanceManager().getCurrentReactContext();
        ImageButton acceptCallBtn = (ImageButton) findViewById(R.id.accept_call_btn);
        acceptCallBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                WritableMap params = Arguments.createMap();
                params.putBoolean("done", true);
                removeNotification(fallBack,notifID);
                Bundle bundle = new Bundle();
                bundle.putString("data", notification);
                bundle.putString("action", "ANSWER");

                RNPushNotificationHelper helper = new RNPushNotificationHelper((Application) getApplicationContext());
                helper.invokeApp(bundle);
                finish();
            }
        });

        ImageButton rejectCallBtn = (ImageButton) findViewById(R.id.reject_call_btn);
        rejectCallBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                WritableMap params = Arguments.createMap();
                params.putBoolean("done", true);
                removeNotification(fallBack,notifID);
                Bundle bundle = new Bundle();
                bundle.putString("data",notification);
                bundle.putString("action","DECLINE");
                if(appState.equals("background")) {
                    RNPushNotificationHelper helper = new RNPushNotificationHelper((Application) getApplicationContext());
                    helper.invokeApp(bundle);
                }else{
                    sendEvent(reactContext, "appInvoked2",Arguments.fromBundle(bundle));
                }
                NotificationUtils.getInstance(getApplicationContext()).sendCallResponse(notification);
                finish();
            }
        });

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                removeNotification(fallBack, notifID);
                finish();
            }
        }, 31000);
    }

    @Override
    protected void onResume() {
        super.onResume();
            mBroadcastReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    Log.d(TAG, "Call Message Broadcast: " + intent.getExtras().toString());
                    if (intent.getAction().equals(CALL_CANCELLED)) {
//                        CommonFunctions.lockPhone(getApplicationContext());
                        removeNotification(fallBack, notifID);
                        finish();
                    }
                }
            };
            IntentFilter mIntentFilter = new IntentFilter(CALL_CANCELLED);
            registerReceiver(mBroadcastReceiver, mIntentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
//        unregisterReceiver(mBroadcastReceiver);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mBroadcastReceiver);
//        ringtone.stop();
    }

    @Override
    public void onConnected() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
//                ...
            }
        });
    }


    @Override
    public void onConnectFailure() {

    }

    @Override
    public void onIncoming(ReadableMap params) {

    }

    private void removeNotification(Boolean fallBack,Integer notifID){
        try {
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancel(1020);
            if(HeadsUpNotificationService.instance!=null)
                HeadsUpNotificationService.instance.stopForeground(true);

        }catch(Exception e){
            e.printStackTrace();
        }
        getApplicationContext().stopService(new Intent(getApplicationContext(), HeadsUpNotificationService.class));
//        if(fallBack) {
//            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//            manager.cancel(notifID);
//        }
//        Intent serviceIntent = new Intent(getApplicationContext(), HeadsUpNotificationService.class);
//        Bundle mBundle = new Bundle();
//        mBundle.putString("type", "cancel_call");
//        mBundle.putString("title", "");
//        serviceIntent.putExtras(mBundle);
//        ContextCompat.startForegroundService(getApplicationContext(), serviceIntent);
    }

    private void sendEvent(ReactContext reactContext, String eventName, WritableMap params) {
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
            .emit(eventName, params);
    }

}