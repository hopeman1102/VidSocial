package com.inwi.vidsocial.notification;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.dieam.reactnativepushnotification.modules.RNPushNotificationHelper;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.inwi.vidsocial.notification.utils.NotificationUtils;

public class HeadsUpNotificationActionReceiver extends BroadcastReceiver {
    private static final String TAG = HeadsUpNotificationActionReceiver.class.getSimpleName();
    String notification;

    @Override
    public void onReceive(Context context, Intent intent) {
//        Log.d("HeadsUpNotificationActionReceiver","Action received: ");
        if (intent != null && intent.getExtras() != null) {
            String action = intent.getStringExtra("ACTION_TYPE");
//            title = intent.getStringExtra("title");
//            body = intent.getStringExtra("body");
            notification = intent.getStringExtra("data");
            Log.d(TAG, "Notification action received: " + notification.toString());
            if (action != null && !action.equalsIgnoreCase("")) {
                performClickAction(context, action, notification);
            }

           // Close the notification after the click action is performed.

//            Intent it = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
//            context.sendBroadcast(it);

            context.stopService(new Intent(context, HeadsUpNotificationService.class));
        }
    }

    private void performClickAction(Context context, String action, String notification) {
        Log.d(TAG, "action:==>" + action);
        Log.d(TAG, "Notification clicked: " + notification.toString());

//        else {
        RNPushNotificationHelper helper = new RNPushNotificationHelper((Application) context.getApplicationContext());
        Bundle bundle = new Bundle();
        bundle.putString("data", notification);
        bundle.putString("action", action);
        helper.invokeApp(bundle);
//            this.clearAbortBroadcast();
//            context.sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
//        }
        if(action.equalsIgnoreCase("DECLINE")){
            NotificationUtils.getInstance(context).sendCallResponse(notification);
        }
    }

    private void sendEvent(ReactContext reactContext, String eventName, WritableMap params) {
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
            .emit(eventName, params);
    }
}