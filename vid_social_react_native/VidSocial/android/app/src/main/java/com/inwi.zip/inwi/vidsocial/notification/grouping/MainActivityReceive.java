package  com.inwi.vidsocial.notification.grouping;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.RemoteInput;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivityReceive extends AppCompatActivity {

    TextView reply_msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main_receive);
//        reply_msg=findViewById(R.id.reply_msg);
        getReplyValue();
    }
    private String KEY_REPLY ="key_reply";
    public void getReplyValue()
    {

        Intent intent = this.getIntent();
        Bundle remoteInput = RemoteInput.getResultsFromIntent(intent);
        if (remoteInput != null) {
            CharSequence inputString = remoteInput.getCharSequence(KEY_REPLY);
            reply_msg.setText(inputString != null ? inputString.toString() : "");
            /*Notification replyNotif = new NotificationCompat.Builder(this, CHANNEL_2_ID)
                    .setSmallIcon(android.R.drawable.sym_def_app_icon)
                    .setContentText("your reply receiver")
                    .build();

            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            notificationManager.notify(notificationId, replyNotif);*/
        }

    }

}