package com.inwi.vidsocial.modules;

import static android.content.Context.AUDIO_SERVICE;

import android.app.ActivityManager;
import android.app.Application;
import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Context;
import android.media.AudioManager;
import android.os.Build;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.inwi.vidsocial.notification.RNPushNotificationListenerService;

import java.util.List;

public class AppStateModule extends ReactContextBaseJavaModule {

    private static final String TAG = AppStateModule.class.getSimpleName();
    private boolean isInBackground;



    public AppStateModule(ReactApplicationContext context) {
        super(context);
    }

    @NonNull
    @Override
    public String getName() {
        return "AppStateModule";
    }

//    @ReactMethod
//    public boolean isInBackground(){
//        ActivityManager.RunningAppProcessInfo myProcess = new ActivityManager.RunningAppProcessInfo();
//        ActivityManager.getMyMemoryState(myProcess);
//        isInBackground = myProcess.importance != ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND;
//        return isInBackground;
//    }

    @ReactMethod
    public void getAppState(Promise promise) {

        promise.resolve(RNPushNotificationListenerService.appState);
    }

    @ReactMethod
    public void isPhoneLocked(Promise promise){
        ReactApplicationContext reactContext = getReactApplicationContext();
        Application applicationContext = (Application) reactContext.getApplicationContext();
        KeyguardManager myKM = (KeyguardManager) applicationContext.getSystemService(Context.KEYGUARD_SERVICE);
        promise.resolve(myKM.inKeyguardRestrictedInputMode());
    }

    @ReactMethod
    public void getScreenStatus(Promise promise) {
        promise.resolve(RNPushNotificationListenerService.screenStatus);
    }

    @ReactMethod
    public void lockPhone(){
        ReactApplicationContext reactContext = getReactApplicationContext();
        Application context = (Application) reactContext.getApplicationContext();
        CommonFunctions.lockPhone(context);
    }

    @ReactMethod
    public void isPhoneSilent(Promise promise){
        AudioManager am = (AudioManager) getReactApplicationContext().getApplicationContext().getSystemService(AUDIO_SERVICE);
//        promise.resolve(am.getRingerMode());

        switch (am.getRingerMode()) {
            case AudioManager.RINGER_MODE_SILENT:
            case AudioManager.RINGER_MODE_VIBRATE:
                promise.resolve(true);
                break;
            case AudioManager.RINGER_MODE_NORMAL:
            default:
                promise.resolve(false);
        }
    }

    @ReactMethod
    public void getVolumeLevel(Promise promise){
        AudioManager am = (AudioManager) getReactApplicationContext().getApplicationContext().getSystemService(AUDIO_SERVICE);
        int volumeLevel= am.getStreamVolume(AudioManager.STREAM_RING);
        promise.resolve(volumeLevel);
    }

    @ReactMethod
    public boolean isInBackground() {
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) getReactApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(getReactApplicationContext().getPackageName())) {
                            isInBackground = false;
                        }
                    }
                }
            }
        } else {
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            if (componentInfo.getPackageName().equals(getReactApplicationContext().getPackageName())) {
                isInBackground = false;
            }
        }

        return isInBackground;
    }
}