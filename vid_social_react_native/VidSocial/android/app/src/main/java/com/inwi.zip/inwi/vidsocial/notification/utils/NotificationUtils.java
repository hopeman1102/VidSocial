package com.inwi.vidsocial.notification.utils;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;

import androidx.core.app.NotificationCompat;

//import com.inwi.vidsocial.R;
import com.inwi.vidsocial.modules.CommonFunctions;
import com.inwi.vidsocial.utils.LocalStorage;
import com.inwi.vidsocial.utils.ServerUtilities;
import com.vidsocial.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
//import com.tencent.mmkv.MMKV;

/**
 * Created by Mac on 05/02/17.
 */
public class NotificationUtils {

    private static String TAG = NotificationUtils.class.getSimpleName();            ;
    public static final String TYPE_NOTIFICATION = "notification";

    // broadcast receiver intent filters
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";
    private final LocalStorage localStorage;

    private Context mContext;
    private MediaPlayer mediaPlayer;

//    private MMKV mmkv;
    private Vibrator vibrator;

    private static NotificationUtils instance;

    public NotificationUtils(Context mContext) {

        this.mContext = mContext;
        vibrator = (Vibrator) mContext.getSystemService(Context.VIBRATOR_SERVICE);
        localStorage = new LocalStorage(mContext);
//        mmkv = MMKV.defaultMMKV();
    }

    public static NotificationUtils getInstance(Context context){
        if(instance==null){
            return new NotificationUtils(context);
        }
        return instance;
    }

    public void sendCallResponse(String notification){
        try {
            // Stop vibrator if it's running
            if (vibrator != null && vibrator.hasVibrator())
                vibrator.cancel();
        } catch (Exception e) {
            Log.e(TAG, "Vibration Stop Error: " + e.getMessage());
        }

        try {
            JSONObject msg = parseNotification(notification);
            Log.d(TAG, "Call Response Params 1:" + msg.toString());
//            JSONObject msg = notify.getJSONObject("alert") ;

            JSONObject currentUser = new JSONObject(localStorage.getString("user_data"));
            JSONObject msgData = new JSONObject();
            msgData.put("receiverid", msg.getString("senderid"));
            msgData.put("acceptid", currentUser.getString("_id"));
            msgData.put("identityResponse", currentUser.getString("identityResponse"));
            msgData.put("callresponse", 0);
            msgData.put("platform", "App");
            msgData.put("platform_os", "Android");
            msgData.put("callerroom", msg.getString("channelname"));
            msgData.put("callInitiatedFromMobile", msg.getBoolean("callInitiatedFromMobile"));

            JSONObject data = new JSONObject();
            data.put("message", msgData.toString());
            data.put("to", msg.getString("identityResponse"));
            data.put("from", currentUser.getString("identityResponse"));
            data.put("eventName", "calling_response");

            JSONObject jsonParams = new JSONObject();
            jsonParams.put("type", "event");
            jsonParams.put("event", "callResponse_notification");
            jsonParams.put("data", data);


            String url = localStorage.getString("api_url") + "callResponse_notification";
            Log.d(TAG, "Call Response Params:" + jsonParams.toString());
            Log.d(TAG, "Call Response URL:" + url);

            // Execute network request in a background thread
            executeNetworkRequest(url, jsonParams.toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static JSONObject parseNotification(String jsonString) {
        try {
            JSONObject jsonObject = new JSONObject(jsonString);
            String alertString = jsonObject.getString("alert");
            Log.d(TAG, "Call alert 1:" + alertString);
            // Remove extra double quotes from the beginning and end of the string
//            alertString = alertString.substring(1, alertString.length() - 1);
            Log.d(TAG, "Call alert 2:" + alertString);
            // Unescape the escaped double quotes in the string
            alertString = alertString.replace("\\\"", "\"");
            Log.d(TAG, "Call alert 3:" + alertString);

            JSONObject alertObject = new JSONObject(alertString);
            return alertObject;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void executeNetworkRequest(String url, String requestData) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.submit(() -> {
            try {
                long startTime = System.currentTimeMillis();
                String result = ServerUtilities.post(url, requestData);
                Log.d(TAG, "Call Response API Result: " + result);
//                KeyguardManager myKM = (KeyguardManager) mContext.getSystemService(Context.KEYGUARD_SERVICE);
//                if(myKM.inKeyguardRestrictedInputMode()) {
//                    CommonFunctions.lockPhone(mContext);
//                }
                // Process result if needed
                processResult(result);
            } catch (IOException e) {
                Log.d(TAG, "Call Response API Failed: " + e.getMessage());
            }
        });
    }

    private void processResult(String result) {
        if (result != null) {
            try {
                JSONObject jObj = new JSONObject(result);
                // Process JSONObject if needed
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public void showNotificationMessage(String title, String message, String timeStamp, Intent intent) {
        showNotificationMessage(title, message, timeStamp, intent, null);
    }

    public void showNotificationMessage(final String title, final String message, final String timeStamp, Intent intent, String imageUrl) {
        // Check for empty push message
        if (TextUtils.isEmpty(message))
            return;
        // notification icon
        final int icon = R.mipmap.ic_launcher;

        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        final PendingIntent resultPendingIntent =
                PendingIntent.getActivity(mContext,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
        //PendingIntent.FLAG_CANCEL_CURRENT

        final NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                mContext);

        /*final Uri alarmSound = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE
                + "://" + mContext.getPackageName() + "/raw/notification");*/
        final Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        if (!TextUtils.isEmpty(imageUrl)) {

            if (imageUrl != null && imageUrl.length() > 4 && Patterns.WEB_URL.matcher(imageUrl).matches()) {

                Bitmap bitmap = getBitmapFromURL(imageUrl);

                if (bitmap != null) {
                    showBigNotification(bitmap, mBuilder, icon, title, message, timeStamp, resultPendingIntent, alarmSound);
                } else {
                    showSmallNotification(mBuilder, icon, title, message, timeStamp, resultPendingIntent, alarmSound);
                }
            }
        } else {
            showSmallNotification(mBuilder, icon, title, message, timeStamp, resultPendingIntent, alarmSound);
            //playNotificationSound();
        }
    }


    private void showSmallNotification(NotificationCompat.Builder mBuilder, int icon, String title, String message, String timeStamp, PendingIntent resultPendingIntent, Uri alarmSound) {
        Notification.InboxStyle inboxStyle = new Notification.InboxStyle();
        inboxStyle.addLine(message);

        Notification notification = new Notification.Builder(mContext).setSmallIcon(icon).setTicker(title).setWhen(0)
                .setAutoCancel(true)
                .setContentTitle(title)
                .setContentIntent(resultPendingIntent)
                .setSound(alarmSound)
                .setStyle(inboxStyle)
                .setWhen(getTimeMilliSec(timeStamp))
                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), icon))
                .setContentText(message)
                .build();

        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(new Random().nextInt(99) + 1, notification);
    }

    private void showBigNotification(Bitmap bitmap, NotificationCompat.Builder mBuilder, int icon, String title, String message, String timeStamp, PendingIntent resultPendingIntent, Uri alarmSound) {
        NotificationCompat.BigPictureStyle bigPictureStyle = new NotificationCompat.BigPictureStyle();
        bigPictureStyle.setBigContentTitle(title);
        bigPictureStyle.setSummaryText(Html.fromHtml(message).toString());
        bigPictureStyle.bigPicture(bitmap);
        Notification notification;
        notification = mBuilder.setSmallIcon(icon).setTicker(title).setWhen(0)
                .setAutoCancel(true)
                .setContentTitle(title)
                .setContentIntent(resultPendingIntent)
                .setSound(alarmSound)
                .setStyle(bigPictureStyle)
                .setWhen(getTimeMilliSec(timeStamp))
                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), icon))
                .setContentText(message)
                .build();

        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(101, notification);
    }

    /**
     * Downloading push notification image before displaying it in
     * the notification tray
     */
    public Bitmap getBitmapFromURL(String strURL) {
        try {
            URL url = new URL(strURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Playing notification sound
    public void playNotificationSound() {
//        try {
//            final Uri alarmSound = Uri.parse("android.resource://"+mContext.getPackageName()+"/"+R.raw.);
//            Ringtone r = RingtoneManager.getRingtone(mContext, alarmSound);
//            r.play();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    /**
     * Method checks if the app is in background or not
     */
    public static boolean isAppIsInBackground(Context context) {
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(context.getPackageName())) {
                            isInBackground = false;
                        }
                    }
                }
            }
        } else {
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            if (componentInfo.getPackageName().equals(context.getPackageName())) {
                isInBackground = false;
            }
        }

        return isInBackground;
    }

    // Clears notification tray messages
    public static void clearNotifications(Context context) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancelAll();
    }

    public static long getTimeMilliSec(String timeStamp) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date date = format.parse(timeStamp);
            return date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
}