package com.inwi.vidsocial.modules;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.annotation.NonNull;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.RemoteInput;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
//import com.google.gson.Gson;
//import com.inwi.vidsocial.R;
import com.google.gson.Gson;
import com.inwi.vidsocial.notification.grouping.DirectReplyReceiver;
import com.inwi.vidsocial.notification.grouping.MainActivityNoti;
import com.inwi.vidsocial.notification.grouping.Message;
import com.vidsocial.R;

import java.util.ArrayList;
import java.util.List;

public class NotificationModule extends ReactContextBaseJavaModule {
    private static final String TAG = com.inwi.vidsocial.modules.NotificationModule.class.getSimpleName();
    private static final String CHANNEL_ID = "Trulinco_RN_Notification";
    private static final String BUNDLE_CHANNEL_ID = "Trulinco_channel_2";

    private static final String CHANNEL_NAME = "Trulinco Channel 1";
    private static final String BUNDLE_CHANNEL_NAME = "Trulinco Channel 2";
    private boolean isInBackground;
    private NotificationManagerCompat notificationManager;
    private Context context;
    static List<Message> MESSAGES = new ArrayList<>();
    NotificationCompat.Builder summaryNotificationBuilder;
    int bundleNotificationId = 100;
    int singleNotificationId = 100;
    private NotificationCompat.InboxStyle inboxStyle;
    private List<NotificationItem> notificationList = new ArrayList<>();

    public NotificationModule(ReactApplicationContext context) {
        super(context);
        this.context = context.getApplicationContext();
        createNotificationChannels();
        notificationManager = NotificationManagerCompat.from(context);

    }

    public class NotificationItem{
        private NotificationCompat.Builder builder;
        private NotificationCompat.MessagingStyle style;
        private int id;
        NotificationItem(int id, NotificationCompat.Builder builder, NotificationCompat.MessagingStyle style){
            this.id=id;
            this.builder = builder;
            this.style = style;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public NotificationCompat.Builder getBuilder() {
            return builder;
        }

        public void setBuilder(NotificationCompat.Builder builder) {
            this.builder = builder;
        }

        public NotificationCompat.MessagingStyle getStyle() {
            return style;
        }

        public void setStyle(NotificationCompat.MessagingStyle style) {
            this.style = style;
        }
    }

    @NonNull
    @Override
    public String getName() {
        return "NotificationModule";
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel1 = new NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            );
            channel1.setDescription("This is Channel 1");

            NotificationChannel channel2 = new NotificationChannel(
                BUNDLE_CHANNEL_ID,
                BUNDLE_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            );
            channel2.setDescription("This is Channel 2");

            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel1);
            notificationManager.createNotificationChannel(channel2);
        }
    }

    @ReactMethod
    public static void sendChannel1Notification(Context context) {
        String packageName = context.getPackageName();
        Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        String className = launchIntent.getComponent().getClassName();
        Class mainClass = null;
        try {
            mainClass = Class.forName(className);
            return ;
        } catch (ClassNotFoundException e) {
            Log.e("ClassNotFoundException==>",e.toString());
            e.printStackTrace();
        }

        Intent activityIntent = new Intent(context, mainClass);
        PendingIntent contentIntent = PendingIntent.getActivity(context,
            0, activityIntent, PendingIntent.FLAG_MUTABLE);

        RemoteInput remoteInput = new RemoteInput.Builder("key_text_reply")
            .setLabel("Your answer...")
            .build();

        Intent replyIntent;
        PendingIntent replyPendingIntent = null;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            replyIntent = new Intent(context, DirectReplyReceiver.class);
            replyPendingIntent = PendingIntent.getBroadcast(context,
                0, replyIntent, PendingIntent.FLAG_MUTABLE);
        } else {
            //start chat activity instead (PendingIntent.getActivity)
            //cancel notification with notificationManagerCompat.cancel(id)
        }

        NotificationCompat.Action replyAction = new NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_report_image,
            "Reply",
            replyPendingIntent
        ).addRemoteInput(remoteInput).build();

        NotificationCompat.MessagingStyle messagingStyle =
            new NotificationCompat.MessagingStyle("Me");
        messagingStyle.setConversationTitle("Group Chat");

        for (Message chatMessage : MESSAGES) {
            NotificationCompat.MessagingStyle.Message notificationMessage =
                new NotificationCompat.MessagingStyle.Message(
                    chatMessage.getText(),
                    chatMessage.getTimestamp(),
                    chatMessage.getSender()
                );
            messagingStyle.addMessage(notificationMessage);
        }

        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setStyle(messagingStyle)
            .addAction(replyAction)
            .setColor(Color.BLUE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .build();

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        notificationManager.notify(1, notification);
    }

    int notificationId = 1;
    private String KEY_REPLY = "key_reply";

    public NotificationManager getNotificationManagerService(){
        return (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    @ReactMethod
    private void showGroupNotification(int id, String contentTitle,String contentText, String data) {

        //  Create Notification
//        Bitmap bm = BitmapFactory.decodeResource(getApplication().getResources(),
//            R.drawable.user3);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//        notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Notification Group Key
        String groupKey = "bundle_notification_" + bundleNotificationId;

        //  Notification Group click intent
        Intent resultIntent = new Intent(context, MainActivityNoti.class);
        resultIntent.putExtra("notification", "Summary Notification");
        resultIntent.putExtra("notification_id", bundleNotificationId);
        resultIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent resultPendingIntent = PendingIntent.getActivity(context, bundleNotificationId, resultIntent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT);

        // We need to update the bundle notification every time a new notification comes up
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            if (notificationManager.getNotificationChannels().size() < 2) {
                NotificationChannel groupChannel = new NotificationChannel(BUNDLE_CHANNEL_ID, BUNDLE_CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW);
                notificationManager.createNotificationChannel(groupChannel);
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
                notificationManager.createNotificationChannel(channel);
            }
        }
        summaryNotificationBuilder = new NotificationCompat.Builder(context, BUNDLE_CHANNEL_ID)
            .setGroup(groupKey)
            .setGroupSummary(true)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher_round)
//            .setLargeIcon(R.drawable.ic_launcher)
            .setAutoCancel(true)
            .setContentIntent(resultPendingIntent);


        if (singleNotificationId == bundleNotificationId)
            singleNotificationId = bundleNotificationId + 1;
        else
            singleNotificationId++;

        //  Individual notification click intent
        resultIntent = new Intent(context, MainActivityNoti.class);
        resultIntent.putExtra("notification", "Single Notification");
        resultIntent.putExtra("notification_id", singleNotificationId);
        resultIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        resultPendingIntent = PendingIntent.getActivity(context, singleNotificationId, resultIntent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT);


        NotificationCompat.Builder notification = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setGroup(groupKey)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher_round)
//            .setLargeIcon(bm)
            .setSound(defaultSoundUri)
            .setAutoCancel(true)
            .setGroupSummary(false)
            .setContentIntent(resultPendingIntent);

        notificationManager.notify(singleNotificationId, notification.build());
        notificationManager.notify(bundleNotificationId, summaryNotificationBuilder.build());
    }

    @ReactMethod
    public void sendStackNotificationIfNeeded() {
        // only run this code if the device is running 23 or better
        if (Build.VERSION.SDK_INT >= 23) {
            String groupName = "trulinco_group";
            ArrayList<StatusBarNotification> groupedNotifications = new ArrayList<>();

            // step through all the active StatusBarNotifications and

            for (StatusBarNotification sbn : getNotificationManagerService().getActiveNotifications()) {
                // add any previously sent notifications with a group that matches our RemoteNotification
                // and exclude any previously sent stack notifications
//                if (remoteNotification.getUserNotificationGroup() != null &&
//                    remoteNotification.getUserNotificationGroup().equals(sbn.getNotification().getGroup()) &&
//                    sbn.getId() != RemoteNotification.TYPE_STACK) {

                    groupedNotifications.add(sbn);
//                }
            }


            // since we assume the most recent notification was delivered just prior to calling this method,
            // we check that previous notifications in the group include at least 2 notifications
            if (groupedNotifications.size() > 1) {
                NotificationCompat.Builder builder = new NotificationCompat.Builder(context);

                // use convenience methods on our RemoteNotification wrapper to create a title
                builder.setContentTitle(String.format("%s: %s", "Trulinco", "Notification Error"))
                    .setContentText(String.format("%d new messages", groupedNotifications.size()));

                // for every previously sent notification that met our above requirements,
                // add a new line containing its title to the inbox style notification extender
                NotificationCompat.InboxStyle inbox = new NotificationCompat.InboxStyle();
                {
                    for (StatusBarNotification activeSbn : groupedNotifications) {
                        String stackNotificationLine = (String)activeSbn.getNotification().extras.get(NotificationCompat.EXTRA_TITLE);
                        if (stackNotificationLine != null) {
                            inbox.addLine(stackNotificationLine+" - custom");
                        }
                    }

                    // the summary text will appear at the bottom of the expanded stack notification
                    // we just display the same thing from above (don't forget to use string
                    // resource formats!)
                    inbox.setSummaryText(String.format("%d new activities", groupedNotifications.size()));
                }
                builder.setStyle(inbox);

                // make sure that our group is set the same as our most recent RemoteNotification
                // and choose to make it the group summary.
                // when this option is set to true, all previously sent/active notifications
                // in the same group will be hidden in favor of the notifcation we are creating
                builder.setGroup(groupName)
                    .setGroupSummary(true);

                // if the user taps the notification, it should disappear after firing its content intent
                // and we set the priority to high to avoid Doze from delaying our notifications
                builder.setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH);
                builder.setChannelId(CHANNEL_ID);

                // create a unique PendingIntent using an integer request code.
                final int requestCode = (int)System.currentTimeMillis() / 1000;
                Intent tapResultIntent = new Intent(context, MainActivityNoti.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(
                    context,
                    notificationId,
                    tapResultIntent,
                    PendingIntent.FLAG_MUTABLE
                );
                builder.setContentIntent(PendingIntent.getActivity(context, requestCode, tapResultIntent,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT));
//                builder.setSmallIcon(R.drawable.ic_notification);
                Notification stackNotification = builder.build();
                stackNotification.defaults = Notification.DEFAULT_ALL;


                // finally, deliver the notification using the group identifier as the Tag
                // and the TYPE_STACK which will cause any previously sent stack notifications
                // for this group to be updated with the contents of this built summary notification
                try {
                    notificationManager.notify(groupName, 0, stackNotification);
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @ReactMethod
    public void getAllNotification(Promise promise){
        ArrayList<StatusBarNotification> groupedNotifications = new ArrayList<>();

        // step through all the active StatusBarNotifications and

        for (StatusBarNotification sbn : getNotificationManagerService().getActiveNotifications()) {
            // add any previously sent notifications with a group that matches our RemoteNotification
            // and exclude any previously sent stack notifications
//                if (remoteNotification.getUserNotificationGroup() != null &&
//                    remoteNotification.getUserNotificationGroup().equals(sbn.getNotification().getGroup()) &&
//                    sbn.getId() != RemoteNotification.TYPE_STACK) {

            groupedNotifications.add(sbn);
//                }
        }
        promise.resolve(new Gson().toJson(groupedNotifications));
    }

    @ReactMethod
    public void showLocalNotification(ReadableMap remoteMessage) {
        _showLocalNotification(remoteMessage,null);
    }

    public void _showLocalNotification(ReadableMap remoteMessage,Bitmap largeImage){
        Bundle bundle = Arguments.toBundle(remoteMessage);

        if(bundle==null){
            return;
        }

        int id = Integer.parseInt(bundle.getString("id"));
        String title = bundle.getString("title");
        String message = bundle.getString("message");
        String largeIconUrl = bundle.getString("largeIconUrl");
//        JSONArray msgList;
//        try {
//            msgList = new JSONArray(messages);
//            String message = msgList.getJSONObject(0).getString("msg");

        NotificationCompat.Builder notificationBuilder = null;
        NotificationItem notificationItem = null;
        if(notificationList.size()>0) {
            int index = 0;
            for (NotificationItem item : notificationList) {
                NotificationCompat.Builder builder = item.getBuilder();
                String oldTitle = builder.build().extras.getString(NotificationCompat.EXTRA_TITLE);
                if (oldTitle.equals(title)) {
                    NotificationCompat.MessagingStyle messagingStyle = new NotificationCompat.MessagingStyle(title);
//                    for(int i=0;i<msgList.length();i++) {
//                        messagingStyle.addMessage(new NotificationCompat.MessagingStyle.Message(
//                            msgList.getJSONObject(i).getString("msg"),
//                            System.currentTimeMillis(),
//                            title
//                        ));
//                    }
//                    notificationBuilder.setStyle(messagingStyle);
                    List<NotificationCompat.MessagingStyle.Message> messages = item.style.getMessages();

                    for(int i = (messages.size()>6?messages.size()-6 : 0); i <  messages.size(); i++) {
                        NotificationCompat.MessagingStyle.Message singleMessage = messages.get(i);
                        messagingStyle.addMessage(singleMessage);
                    }

                    NotificationCompat.MessagingStyle.Message newMessage = new NotificationCompat.MessagingStyle.Message(
                        message,
                        System.currentTimeMillis(),
                        title
                    );

                    messagingStyle.addMessage(newMessage);
                    item.style.addMessage(newMessage);
                    notificationList.set(index,item);

                    builder.setStyle(messagingStyle);
                    item.setBuilder(builder);
                    id = item.getId();
                    notificationBuilder = item.getBuilder();
                } else {
//                    notificationBuilder = item.getBuilder();
//                    notificationItem = addNewNotification(id, title, message);
//                    notificationBuilder = notificationItem.getBuilder();
                }
                index ++;
            }

            if(notificationBuilder == null){
//                if(largeIconUrl==null || largeImage!=null) {
                    notificationItem = addNewNotification(id, title, message,bundle,largeImage);
                    notificationBuilder = notificationItem.getBuilder();

//                }else{
//                    RNPushNotificationPicturesAggregator aggregator = new RNPushNotificationPicturesAggregator(new RNPushNotificationPicturesAggregator.Callback() {
//                        public void call(Bitmap largeIconImage, Bitmap bigPictureImage, Bitmap bigLargeIconImage) {
//                            _showLocalNotification(remoteMessage,largeIconImage);
//                        }
//                    });
//                    aggregator.setLargeIconUrl(context, bundle.getString("largeIconUrl"));
//                }
            }
        }else{
//            if(largeIconUrl==null || largeIconUrl.trim().equals("") || largeImage!=null) {
                notificationItem = addNewNotification(id, title, message,bundle,largeImage);
                notificationBuilder = notificationItem.getBuilder();
//            }else{
//                RNPushNotificationPicturesAggregator aggregator = new RNPushNotificationPicturesAggregator(new RNPushNotificationPicturesAggregator.Callback() {
//                    public void call(Bitmap largeIconImage, Bitmap bigPictureImage, Bitmap bigLargeIconImage) {
//                        _showLocalNotification(remoteMessage,largeIconImage);
//                    }
//                });
//                aggregator.setLargeIconUrl(context, largeIconUrl);
//            }
        }

        if(notificationBuilder!=null) {
            if (notificationItem != null) {
                notificationList.add(notificationItem);
            }

            Notification notification1 = notificationBuilder.build();

            if (inboxStyle == null) {
                inboxStyle = new NotificationCompat.InboxStyle()
//                    .addLine(title2 + " " + message2)
                    .addLine(title + " " + message);
//                .setBigContentTitle("2 new messages")
//                .setSummaryText("New Message received")
            } else {
                inboxStyle.addLine(title + " " + message);
            }

            if (summaryNotificationBuilder == null) {
                summaryNotificationBuilder = new NotificationCompat.Builder(context, BUNDLE_CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher_round)
                    .setStyle(inboxStyle)
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setGroup("trulinco_group")
                    .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
                    .setGroupSummary(true)
                    .setOnlyAlertOnce(true);
            } else {
                summaryNotificationBuilder.setStyle(inboxStyle);
            }

            Notification summaryNotification = summaryNotificationBuilder.build();

            final Handler handler = new Handler(Looper.getMainLooper());
            int finalId = id;
            handler.postDelayed(() -> notificationManager.notify(finalId, notification1), 100);

//        final Handler handler2 = new Handler(Looper.getMainLooper());
//        handler2.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//
//                notificationManager.notify(3, notification2);
//            }
//        }, 600);

            final Handler handler3 = new Handler(Looper.getMainLooper());
            handler3.postDelayed(() -> notificationManager.notify(0, summaryNotification), 300);

//        } catch (JSONException e) {
//            e.printStackTrace();
//            return;
//        }
        }
    }

    @ReactMethod
    public void clearNotification(String title){
        if(notificationList.size()>0) {
            int index = -1;
            for (NotificationItem item : notificationList) {
                index++;
                String oldTitle = item.getBuilder().build().extras.getString(NotificationCompat.EXTRA_TITLE);
                if(oldTitle.equals(title)){
                    try {
                        notificationManager.cancel(item.getId());
                        if (notificationList.size() == 1) {
                            notificationManager.cancel(0);
                        }
                        notificationList.remove(index);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                    break;
                }
            }
        }
    }

    public Class getMainActivityClass() {
        String packageName = context.getPackageName();
        Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        String className = launchIntent.getComponent().getClassName();
        try {
            return Class.forName(className);
        } catch (ClassNotFoundException e) {
            Log.e("ClassNot=>",e.toString());
            e.printStackTrace();
            return null;
        }
    }

    public boolean isApplicationInForeground() {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> processInfos = activityManager.getRunningAppProcesses();
        if (processInfos != null) {
            for (ActivityManager.RunningAppProcessInfo processInfo : processInfos) {
                if (processInfo.processName.equals(context.getPackageName())
                    && processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
                    && processInfo.pkgList.length > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    private NotificationItem addNewNotification(int id, String title, String message,Bundle bundle, Bitmap largeImage){

        Class intentClass = getMainActivityClass();

        Intent intent = new Intent(context, intentClass);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        bundle.putBoolean("foreground", this.isApplicationInForeground());
        bundle.putBoolean("userInteraction", true);
        intent.putExtra("notification", bundle);

        PendingIntent pendingIntent = PendingIntent.getActivity(context, id, intent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT);

//        Intent tapResultIntent = new Intent(context, intentClass);
//        PendingIntent pendingIntent = PendingIntent.getActivity(
//            context,
//            notificationId,
//            tapResultIntent,
//            PendingIntent.FLAG_MUTABLE
//        );

        RemoteInput remoteInput = new RemoteInput.Builder(KEY_REPLY)
            .setLabel("Insert your name")
            .build();

        NotificationCompat.Action replyAction = new NotificationCompat.Action.Builder(
            0,
            "REPLY",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();
        NotificationCompat.Action replyAction1 = new NotificationCompat.Action.Builder(
            0,
            "MARK AS READ",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();

        NotificationCompat.Action replyAction2 = new NotificationCompat.Action.Builder(
            0,
            "MUTE",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();

        NotificationCompat.MessagingStyle messagingStyle = new NotificationCompat.MessagingStyle(title);
        messagingStyle.addMessage(new NotificationCompat.MessagingStyle.Message(
            message,
            System.currentTimeMillis(),
            title
        ));
//        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_launcher);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setChannelId(CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setLargeIcon(largeImage)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(messagingStyle)
            .setContentIntent(pendingIntent)
//            .addAction(replyAction)
//            .addAction(replyAction1)
//            .addAction(replyAction2)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setGroup("trulinco_group");
        NotificationItem item = new NotificationItem(id,notificationBuilder,messagingStyle);

        return item;
    }

    @ReactMethod
    public void showLocalNotification2() {
        String title1 = "Title 1";
        String message1 = "Message 1";
        String title2 = "Shraddha";
        String message2 = "Message 1";

        NotificationCompat.MessagingStyle messagingStyle = new NotificationCompat.MessagingStyle("User");
        messagingStyle.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Hello 1",
            System.currentTimeMillis(),
            "Anjali"
        ));


        // Add message 1
        messagingStyle.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Hello 2",
            System.currentTimeMillis(),
            "Anjali"
        ));


        messagingStyle.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Hello 3",
            System.currentTimeMillis(),
            "Anjali"
        ));
        //////////////
        Intent tapResultIntent = new Intent(context, MainActivityNoti.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            tapResultIntent,
            PendingIntent.FLAG_MUTABLE
        );

        RemoteInput remoteInput = new RemoteInput.Builder(KEY_REPLY)
            .setLabel("Insert your name")
            .build();
        NotificationCompat.Action replyAction = new NotificationCompat.Action.Builder(
            0,
            "REPLY",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();
        NotificationCompat.Action replyAction1 = new NotificationCompat.Action.Builder(
            0,
            "MARK AS READ",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();

        NotificationCompat.Action replyAction2 = new NotificationCompat.Action.Builder(
            0,
            "MUTE",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();

        //////////////////

        NotificationCompat.MessagingStyle messagingStyle1 = new NotificationCompat.MessagingStyle("User");
        messagingStyle1.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Message 1",
            System.currentTimeMillis(),
            "Test2"
        ));

        // Add message 1
        messagingStyle1.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Message 2",
            System.currentTimeMillis(),
            "Test2"
        ));

        messagingStyle1.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Message 3",
            System.currentTimeMillis(),
            "Test2"
        ));

        Notification notification2 = new NotificationCompat.Builder(context, BUNDLE_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title2)
            .setContentText(message2)
            .setStyle(messagingStyle1)
            .addAction(replyAction)
            .addAction(replyAction1)
            .addAction(replyAction2)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setGroup("trulinco_group")
            .build();


        Notification notification1 = new NotificationCompat.Builder(getReactApplicationContext(), BUNDLE_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title1)
            .setContentText(message1)
            .setStyle(messagingStyle)
            .addAction(replyAction)
            .addAction(replyAction1)
            .addAction(replyAction2)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setGroup("trulinco_group")
            .build();


        Notification summaryNotification = new NotificationCompat.Builder(context, BUNDLE_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setStyle(new NotificationCompat.InboxStyle()
                .addLine(title2 + " " + message2)
                .addLine(title1 + " " + message1)
//                .setBigContentTitle("2 new messages")
//                .setSummaryText("New Message received")
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setGroup("trulinco_group")
            .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
            .setGroupSummary(true)
            .build();

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                notificationManager.notify(2, notification1);
            }
        }, 500);

        final Handler handler2 = new Handler(Looper.getMainLooper());
        handler2.postDelayed(new Runnable() {
            @Override
            public void run() {

                notificationManager.notify(3, notification2);
            }
        }, 600);

        final Handler handler3 = new Handler(Looper.getMainLooper());
        handler3.postDelayed(new Runnable() {
            @Override
            public void run() {

                notificationManager.notify(0, summaryNotification);
            }
        }, 700);
    }
}
