package  com.inwi.vidsocial.notification.grouping;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.RemoteInput;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//import com.inwi.vidsocial.R;

import com.inwi.vidsocial.notification.grouping.DirectReplyReceiver;
import com.inwi.vidsocial.notification.grouping.Message;
import com.vidsocial.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivityNoti extends AppCompatActivity {
    private NotificationManagerCompat notificationManager;
    private EditText editTextTitle;
    private EditText editTextMessage;
    private static final String CHANNEL_1_ID = "Trulinco_RN_Notification";
    private static final String CHANNEL_2_ID = "Trulinco_channel_2";

    TextView reply_msg;
    static List<Message> MESSAGES = new ArrayList<>();
    Button get_notification_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main_noti);
//
//        notificationManager = NotificationManagerCompat.from(this);
//        reply_msg=findViewById(R.id.reply_msg);
//        editTextTitle = findViewById(R.id.edit_text_title);
//        editTextMessage = findViewById(R.id.edit_text_message);

        MESSAGES.add(new Message("Good morning!", "Jim"));
        MESSAGES.add(new Message("Hello", null));
        MESSAGES.add(new Message("Hi!", "Jenny"));
    }

    public void sendOnChannel1(View v) {
        sendChannel1Notification(this);
    }

    public static void sendChannel1Notification(Context context) {
        String packageName = context.getPackageName();
        Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        String className = launchIntent.getComponent().getClassName();
        Class mainClass = null;
        try {
            mainClass = Class.forName(className);
            return;
        } catch (ClassNotFoundException e) {
//            Log.e("ClassNotFoundException==>", e.toString());
            e.printStackTrace();
        }
        Intent activityIntent = new Intent(context, mainClass);
        PendingIntent contentIntent = PendingIntent.getActivity(context,
            0, activityIntent, PendingIntent.FLAG_MUTABLE);

        RemoteInput remoteInput = new RemoteInput.Builder("key_text_reply")
            .setLabel("Your answer...")
            .build();

        Intent replyIntent;
        PendingIntent replyPendingIntent = null;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            replyIntent = new Intent(context, DirectReplyReceiver.class);
            replyPendingIntent = PendingIntent.getBroadcast(context,
                0, replyIntent, PendingIntent.FLAG_MUTABLE);
        } else {
            //start chat activity instead (PendingIntent.getActivity)
            //cancel notification with notificationManagerCompat.cancel(id)
        }

        NotificationCompat.Action replyAction = new NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_report_image,
            "Reply",
            replyPendingIntent
        ).addRemoteInput(remoteInput).build();

        NotificationCompat.MessagingStyle messagingStyle =
            new NotificationCompat.MessagingStyle("Me");
        messagingStyle.setConversationTitle("Group Chat");

        for (Message chatMessage : MESSAGES) {
            NotificationCompat.MessagingStyle.Message notificationMessage =
                new NotificationCompat.MessagingStyle.Message(
                    chatMessage.getText(),
                    chatMessage.getTimestamp(),
                    chatMessage.getSender()
                );
            messagingStyle.addMessage(notificationMessage);
        }

        Notification notification = new NotificationCompat.Builder(context, CHANNEL_1_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setStyle(messagingStyle)
            .addAction(replyAction)
            .setColor(Color.BLUE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .build();

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        notificationManager.notify(1, notification);
    }

    int notificationId = 1;
    private String KEY_REPLY = "key_reply";

    public void sendOnChannel2(View v) {
        String title1 = "Title 1";
        String message1 = "Message 1";
        String title2 = "Shraddha";
        String message2 = "Message 1";

        NotificationCompat.MessagingStyle messagingStyle = new NotificationCompat.MessagingStyle("User");
        messagingStyle.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Hello 1",
            System.currentTimeMillis(),
            "Anjali"
        ));

        // Add message 1
        messagingStyle.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Hello 2",
            System.currentTimeMillis(),
            "Anjali"
        ));


        messagingStyle.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Hello 3",
            System.currentTimeMillis(),
            "Anjali"
        ));
        //////////////
        Intent tapResultIntent = new Intent(this, MainActivityNoti.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this,
            notificationId,
            tapResultIntent,
            PendingIntent.FLAG_MUTABLE
        );

        RemoteInput remoteInput = new RemoteInput.Builder(KEY_REPLY)
            .setLabel("Insert your name")
            .build();
        NotificationCompat.Action replyAction = new NotificationCompat.Action.Builder(
            0,
            "REPLY",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();
        NotificationCompat.Action replyAction1 = new NotificationCompat.Action.Builder(
            0,
            "MARK AS READ",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();

        NotificationCompat.Action replyAction2 = new NotificationCompat.Action.Builder(
            0,
            "MUTE",
            pendingIntent
        )
            .addRemoteInput(remoteInput)
            .build();

        //////////////////

        NotificationCompat.MessagingStyle messagingStyle1 = new NotificationCompat.MessagingStyle("User");
        messagingStyle1.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Message 1",
            System.currentTimeMillis(),
            "Test2"
        ));


        // Add message 1
        messagingStyle1.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Message 2",
            System.currentTimeMillis(),
            "Test2"
        ));

        messagingStyle1.addMessage(new NotificationCompat.MessagingStyle.Message(
            "Message 3",
            System.currentTimeMillis(),
            "Test2"
        ));

        Notification notification2 = new NotificationCompat.Builder(this, CHANNEL_2_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title2)
            .setContentText(message2)
            .setStyle(messagingStyle1)
            .addAction(replyAction)
            .addAction(replyAction1)
            .addAction(replyAction2)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setGroup("example_group")
            .build();


        Notification notification1 = new NotificationCompat.Builder(this, CHANNEL_2_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title1)
            .setContentText(message1)
            .setStyle(messagingStyle)
            .addAction(replyAction)
            .addAction(replyAction1)
            .addAction(replyAction2)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setGroup("example_group")
            .build();


        Notification summaryNotification = new NotificationCompat.Builder(this, CHANNEL_2_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setStyle(new NotificationCompat.InboxStyle()
                .addLine(title2 + " " + message2)
                .addLine(title1 + " " + message1)
                .setBigContentTitle("2 new messages")
                .setSummaryText("New Message receive"))
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setGroup("example_group")
            .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
            .setGroupSummary(true)
            .build();


        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                notificationManager.notify(2, notification1);
            }
        }, 1000);

        final Handler handler2 = new Handler(Looper.getMainLooper());
        handler2.postDelayed(new Runnable() {
            @Override
            public void run() {

                notificationManager.notify(3, notification2);
            }
        }, 2000);

        final Handler handler3 = new Handler(Looper.getMainLooper());
        handler3.postDelayed(new Runnable() {
            @Override
            public void run() {

                notificationManager.notify(4, summaryNotification);
            }
        }, 3000);

            /*//SystemClock.sleep(2000);
            notificationManager.notify(2, notification1);
           // SystemClock.sleep(2000);
            notificationManager.notify(3, notification2);
            //SystemClock.sleep(2000);
            notificationManager.notify(4, summaryNotification);*/
    }


    @Override
    protected void onResume() {
        super.onResume();
        getReplyValue();
    }

    public void getReplyValue() {

        Intent intent = this.getIntent();
        Bundle remoteInput = RemoteInput.getResultsFromIntent(intent);
        if (remoteInput != null) {
            CharSequence inputString = remoteInput.getCharSequence(KEY_REPLY);
            reply_msg.setText(inputString != null ? inputString.toString() : "");
            /*Notification replyNotif = new NotificationCompat.Builder(this, CHANNEL_2_ID)
                    .setSmallIcon(android.R.drawable.sym_def_app_icon)
                    .setContentText("your reply receiver")
                    .build();

            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            notificationManager.notify(notificationId, replyNotif);*/
        }

    }
}


