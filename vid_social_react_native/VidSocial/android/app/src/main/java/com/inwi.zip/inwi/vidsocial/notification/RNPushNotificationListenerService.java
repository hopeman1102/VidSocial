package com.inwi.vidsocial.notification;

import com.dieam.reactnativepushnotification.modules.RNPushNotificationJsDelivery;

import com.dieam.reactnativepushnotification.modules.RNReceivedMessageHandler;
import com.facebook.react.bridge.ReadableMap;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.facebook.react.ReactApplication;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;
import com.inwi.vidsocial.notification.HeadsUpNotificationService;
//import com.inwi.vidsocial.R;

import static com.dieam.reactnativepushnotification.modules.RNPushNotification.LOG_TAG;
import static com.inwi.vidsocial.notification.LockScreenActivity.CALL_CANCELLED;

import org.json.JSONException;
import org.json.JSONObject;

public class RNPushNotificationListenerService extends FirebaseMessagingService {

    private static final String TAG = RNPushNotificationListenerService.class.getSimpleName();
    private RNReceivedMessageHandler mMessageReceivedHandler;
    private FirebaseMessagingService mFirebaseServiceDelegate;
    private String CHANNEL_ID = "Trulinco_Call_Notification_Channel";
    private String CHANNEL_NAME = "Incoming Call";
    public static String appState = "background";
    public static String screenStatus = "ON";
    public static String ROOM_NAME = "";
    public static String CALLER_NAME = "";
    public static ReadableMap CALL_INFO = null;
    public static ReadableMap CALLER_INFO = null;

    public RNPushNotificationListenerService() {
        super();
        this.mMessageReceivedHandler = new RNReceivedMessageHandler(this);
    }

    public RNPushNotificationListenerService(FirebaseMessagingService delegate) {
        super();
        this.mFirebaseServiceDelegate = delegate;
        this.mMessageReceivedHandler = new RNReceivedMessageHandler(delegate);
    }

    @Override
    public void onNewToken(String token) {
        final String deviceToken = token;
        final FirebaseMessagingService serviceRef = (this.mFirebaseServiceDelegate == null) ? this : this.mFirebaseServiceDelegate;
        Log.d(LOG_TAG, "Refreshed token: " + deviceToken);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            public void run() {
                // Construct and load our normal React JS code bundle
                final ReactInstanceManager mReactInstanceManager = ((ReactApplication)serviceRef.getApplication()).getReactNativeHost().getReactInstanceManager();
                ReactContext context = mReactInstanceManager.getCurrentReactContext();
                // If it's constructed, send a notification
                if (context != null) {
                    handleNewToken((ReactApplicationContext) context, deviceToken);
                } else {
                    // Otherwise wait for construction, then send the notification
                    mReactInstanceManager.addReactInstanceEventListener(new ReactInstanceManager.ReactInstanceEventListener() {
                        public void onReactContextInitialized(ReactContext context) {
                            handleNewToken((ReactApplicationContext) context, deviceToken);
                            mReactInstanceManager.removeReactInstanceEventListener(this);
                        }
                    });
                    if (!mReactInstanceManager.hasStartedCreatingInitialContext()) {
                        // Construct it in the background
                        mReactInstanceManager.createReactContextInBackground();
                    }
                }
            }
        });
    }

    private void handleNewToken(ReactApplicationContext context, String token) {
        RNPushNotificationJsDelivery jsDelivery = new RNPushNotificationJsDelivery(context);

        WritableMap params = Arguments.createMap();
        params.putString("deviceToken", token);
        jsDelivery.sendEvent("remoteNotificationsRegistered", params);
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        try {
            JSONObject  data = new JSONObject(message.getData());
            Log.d(TAG,"FCM Message ====> "+data.getString("alert"));
            String json = data.getString("alert").replace("\\\"","'");
            json = json.substring(json.indexOf("{"), json.lastIndexOf("}")+1);
            JSONObject msg = new JSONObject(json);
//            if(appState.equals("background")) {
                if (msg.has("channelname")) {
                    Log.d(TAG,"Call Notification entered 111 ====>");
                    ROOM_NAME = msg.getString("channelname");
                } else if (msg.has("callerroom")
                        && msg.getString("callerroom").equals(ROOM_NAME)
                        && (msg.getInt("callresponse")==-2 || msg.getInt("callresponse")==0
                    || (msg.getInt("callresponse")==1 && msg.getBoolean("web_accepted")))) {
                    Log.d(TAG,"Call Notification ====> -1: ");
                    Intent i = new Intent();
                    i.setAction(CALL_CANCELLED);
                    i.setPackage(getPackageName());
                    i.putExtra("msg","hello");
                    sendBroadcast(i);
                    try {
                        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                        notificationManager.cancel(1020);
                        stopForeground(true);
                        this.getApplicationContext().stopService(new Intent(this.getApplicationContext(), HeadsUpNotificationService.class));
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }else{
                    mMessageReceivedHandler.handleReceivedMessage(message);
                }
//            }else{
//                mMessageReceivedHandler.handleReceivedMessage(message);
//            }
        } catch (JSONException e) {
            mMessageReceivedHandler.handleReceivedMessage(message);
            e.printStackTrace();
        }
    }

    public boolean isAppInforegrounded(){
        ActivityManager.RunningAppProcessInfo appProcessInfo = new ActivityManager.RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(appProcessInfo);
        return (appProcessInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND ||
            appProcessInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE);
    }
}
