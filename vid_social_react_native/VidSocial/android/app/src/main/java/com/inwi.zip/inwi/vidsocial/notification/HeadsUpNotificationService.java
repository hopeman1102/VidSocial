package com.inwi.vidsocial.notification;

import static com.dieam.reactnativepushnotification.modules.RNPushNotification.LOG_TAG;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

//import com.inwi.vidsocial.R;

import com.vidsocial.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.List;

public class HeadsUpNotificationService extends Service {
    private static final String TAG = HeadsUpNotificationService.class.getSimpleName();
    private String CHANNEL_ID = "Trulinco_Call_Notification_Channel";
    private String CHANNEL_NAME = "Incoming Call";
    private MediaPlayer mediaPlayer;
    private Context context;
    private NotificationManager notificationManager;
    public static HeadsUpNotificationService instance;

    @Override
    public void onCreate() {
        super.onCreate();
        context = this.getApplicationContext();
        instance = this;
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

//        if (Build.VERSION.SDK_INT >= 26) {
//            String CHANNEL_ID = "my_channel_01";
//            String CHANNEL_NAME = "Ongoing Call";
//            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
//                    CHANNEL_NAME,
//                    NotificationManager.IMPORTANCE_DEFAULT);
//
//            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
//
//            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
//                    .setContentTitle("Dummy Title")
//                    .setContentText("Dummy Message").build();
//
//            startForeground(1, notification);
//        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("ResourceType")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title="",body="",type="",notification = "";
        JSONObject message = null;
        if (intent != null && intent.getExtras() != null) {
            type = intent.getStringExtra("type");
            title = intent.getStringExtra("title");
            body = intent.getStringExtra("body");
            if(type.equals("call")) {

                notification = intent.getStringExtra("data");
                try {
                    message = new JSONObject(notification);
                    message = new JSONObject(message.getString("alert"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //{"SenderId":"89","title":"Adarsh","body":"Video call","alert":"{\"senderid\":89,\"sendername\":\"Adarsh\",\"receiverid\":119,\"channelname\":\"Adarsh_891661509091248\",\"token\":\"\",\"identityResponse\":\"Adarsh_89\",\"profileImageUrl\":\"male.png\",\"mobileNumber\":\"9993383667\",\"languageCode\":\"en\",\"voiceCode\":\"en-IN\",\"gender\":\"M\",\"callInitiatedFromMobile\":true,\"call_type\":\"Video\",\"Latest_call_Type\":\"Video\",\"liveCall\":true}"}
            }else{
//                Log.d(TAG, "Call Message Cancelled:==>"+ title);
            }
        }
        try {
//            Log.d(TAG,"Call Notification ====> 4: "+notification.toString());
            final int pendingIntentFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT;
            if(type.equals("call")) {
//                Log.d(TAG,"Call Notification ====> 5");

                Uri notificationSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);

                Intent receiveCallIntent, cancelCallIntent, openCallIntent;
                PendingIntent receiveCallPendingIntent, cancelCallPendingIntent, openCallPendingIntent;

                if(getApplicationInfo().targetSdkVersion >= Build.VERSION_CODES.S && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
//                    Log.e(LOG_TAG, "Call Notification will open activity: "+appState);
                    String packageName = context.getPackageName();
                    Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage(packageName);
                    String className = launchIntent.getComponent().getClassName();
                    Class<?> activityClass = null;
                    try {
                        activityClass = Class.forName(className);
//                        Log.d(TAG,"Launcher activity class name: "+activityClass.toString());
                    } catch(Exception e) {
                        Log.e(LOG_TAG, "Class not found", e);
                    }
                    Bundle receiveCallBundle = new Bundle();
                    receiveCallBundle.putString("data", notification);
                    receiveCallBundle.putString("action", "ANSWER");
                    receiveCallIntent = new Intent(getApplicationContext(), activityClass);
                    receiveCallIntent.putExtra("notification", receiveCallBundle);

                    Bundle cancelCallBundle = new Bundle();
                    cancelCallBundle.putString("data", notification);
                    cancelCallBundle.putString("action", "DECLINE");
                    cancelCallIntent = new Intent(getApplicationContext(), activityClass);
                    cancelCallIntent.putExtra("notification", cancelCallBundle);

                    Bundle openCallBundle = new Bundle();
                    openCallBundle.putString("data", notification);
                    openCallBundle.putString("action", "OPEN_CALL_SCREEN");
                    openCallIntent = new Intent(getApplicationContext(), activityClass);
                    openCallIntent.putExtra("notification", openCallBundle);

                    receiveCallPendingIntent = PendingIntent.getActivity(getApplicationContext(), 1200, receiveCallIntent, pendingIntentFlag);
                    cancelCallPendingIntent = PendingIntent.getActivity(getApplicationContext(), 1201, cancelCallIntent, pendingIntentFlag);
                    openCallPendingIntent = PendingIntent.getActivity(getApplicationContext(), 1202, openCallIntent, pendingIntentFlag);
                }else{
//                    Log.e(LOG_TAG, "Call Notification will open broadcast");
                    receiveCallIntent = new Intent(getApplicationContext(), HeadsUpNotificationActionReceiver.class);
                    receiveCallIntent.putExtra("ACTION_TYPE", "ANSWER");
                    receiveCallIntent.putExtra("type", "accept");
                    receiveCallIntent.putExtra("title", title);
                    receiveCallIntent.putExtra("body", body);
                    receiveCallIntent.putExtra("data", notification);
                    receiveCallIntent.setAction("ANSWER");

                    cancelCallIntent = new Intent(getApplicationContext(), HeadsUpNotificationActionReceiver.class);
                    cancelCallIntent.putExtra("ACTION_TYPE", "DECLINE");
                    cancelCallIntent.putExtra("type", "reject");
                    cancelCallIntent.putExtra("title", title);
                    cancelCallIntent.putExtra("body", body);
                    cancelCallIntent.putExtra("data", notification);
                    cancelCallIntent.setAction("DECLINE");

                    openCallIntent = new Intent(getApplicationContext(), HeadsUpNotificationActionReceiver.class);
                    openCallIntent.putExtra("ACTION_TYPE", "OPEN_CALL_SCREEN");
                    openCallIntent.putExtra("type", "incoming");
                    openCallIntent.putExtra("title", title);
                    openCallIntent.putExtra("body", body);
                    openCallIntent.putExtra("data", notification);
                    openCallIntent.setAction("OPEN_CALL_SCREEN");

                    receiveCallPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 1200, receiveCallIntent, pendingIntentFlag);
                    cancelCallPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 1201, cancelCallIntent, pendingIntentFlag);
                    openCallPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 1202, openCallIntent, pendingIntentFlag);
                }

                Intent i = new Intent(getApplicationContext(), LockScreenActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                i.putExtra("APP_STATE",isAppRunning());
                i.putExtra("FALL_BACK",true);
                i.putExtra("NOTIFICATION_ID",1020);
                i.putExtra("title", title);
                i.putExtra("body", body);
                i.putExtra("data",notification);
                PendingIntent fullScreenIntent = PendingIntent.getActivity(this, 0 /* Request code */, i,
                    PendingIntent.FLAG_ONE_SHOT|PendingIntent.FLAG_IMMUTABLE);

                NotificationCompat.Builder notificationBuilder = null;
                if (title != null) {
                    notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setContentText((message.getString("call_type").equals("Video")?"Video":"Audio")+" Call")
                        .setContentTitle(title)
                        .setColor(Color.parseColor(getApplicationContext().getResources().getString(R.color.colorAccent)))
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                        .setPriority(NotificationCompat.PRIORITY_MAX)
                        .setCategory(NotificationCompat.CATEGORY_CALL)
                        .addAction(0, "ANSWER", receiveCallPendingIntent)
                        .addAction(0, "DECLINE", cancelCallPendingIntent)
                        .setAutoCancel(true)
                        .setOngoing(true)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setDefaults(Notification.DEFAULT_VIBRATE)
                        .setVibrate(new long[]{300, 300, 300})
                        .setFullScreenIntent(fullScreenIntent, true)
                        .setContentIntent(openCallPendingIntent);
                }
                int importance = NotificationManager.IMPORTANCE_MAX;

                //channel creation start
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    NotificationChannel mChannel = new NotificationChannel(
                        CHANNEL_ID, CHANNEL_NAME, importance);
                    mChannel.setShowBadge(true);
                    mChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                    mChannel.setVibrationPattern(new long[]{300, 300, 300});
                    mChannel.enableLights(true);
                    mChannel.enableVibration(true);
                    mChannel.setDescription(CHANNEL_NAME);
                    notificationManager.createNotificationChannel(mChannel);
                }

                Notification incomingCallNotification = null;
                if (notificationBuilder != null) {
                    incomingCallNotification = notificationBuilder.build();
                }
                startForeground(1020, incomingCallNotification);
                Handler h = new Handler();
                long delayInMilliseconds = 30000;
                h.postDelayed(new Runnable() {
                    public void run() {
                        Log.d(TAG, "Notification Cancelled after timeout");
                        notificationManager.cancel(1020);
                        try {
                            stopForeground(true);
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                }, delayInMilliseconds);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            stopForeground(true);
        }catch(Exception e){
            e.printStackTrace();
        }
        super.onDestroy();
    }

    private boolean isAppRunning() {
        ActivityManager m = (ActivityManager) this.getSystemService( ACTIVITY_SERVICE );
        List<ActivityManager.RunningTaskInfo> runningTaskInfoList =  m.getRunningTasks(10);
        Iterator<ActivityManager.RunningTaskInfo> itr = runningTaskInfoList.iterator();
        int n=0;
        while(itr.hasNext()){
            n++;
            itr.next();
        }
        if(n==1){ // App is killed
            return false;
        }
        return true; // App is in background or foreground
    }
}