package com.inwi.vidsocial.modules;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class CommonModule extends ReactContextBaseJavaModule {

    private static final String TAG = CommonModule.class.getSimpleName();

    public CommonModule(ReactApplicationContext context) {
        super(context);
    }

    @NonNull
    @Override
    public String getName() {
        return "CommonModule";
    }

    @ReactMethod
    public void setValue(String key,String value, Promise promise) {
        promise.resolve(true);
    }

    @ReactMethod
    public void getBaseUrl(String env, Promise promise) {
        promise.resolve("");
    }

    @ReactMethod
    public void getApiUrl(String env, Promise promise) {
        promise.resolve("");
    }

    @ReactMethod
    public void getApiKey(Promise promise) {
        promise.resolve("");
    }
}